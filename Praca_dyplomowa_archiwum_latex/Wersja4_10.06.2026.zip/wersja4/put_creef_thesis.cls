%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% LateX class for Bachelor's & Master's Thesis                          %%
%% based on  Dawid Weiss & Marta Szachniuk                               %%
%% Faculty of Automatic Control, Robotics, and Electrical Engineering    %%
%% Poznan University of Technology, 2023                                 %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This class is UNOFFICIAL and NOT ENDORSED by the university.
% (c) 2006--2011 Dawid Weiss, Poznan University of Technology
% (c) 2012--2017 Przemyslaw Wesolek, Poznan University of Technology
% (c) 2020--     Marta Szachniuk, Poznan University of Technology
% (c) 2023 - version for Faculty of Automatic Control, Robotics, and Electrical Engineering  S. Brock
% (c) 2025 - update S. Brock

\NeedsTeXFormat{LaTeX2e}[2020/10/01]
\ProvidesClass{put_creef_thesis}[2025/10/26 v1.2 guarded microtype + base class early]
\LoadClass[12pt,oneside,a4paper]{memoir}

% --- minimal modernization block (2025-10-26) ----------------------------
\RequirePackage{iftex}
\ifPDFTeX
  \RequirePackage[T1]{fontenc}% UTF-8 default; avoid inputenc
  \IfFileExists{lmodern.sty}{\RequirePackage{lmodern}}{}% pełniejsza rodzina fontów
  \IfFileExists{microtype.sty}{\RequirePackage{microtype}}{}%
\else
  \IfFileExists{microtype.sty}{\RequirePackage{microtype}}{}%
\fi
% -------------------------------------------------------------------------

% --- minimal modernization block (guarded microtype) ---------------------
\RequirePackage{iftex}
\ifPDFTeX
  \RequirePackage[T1]{fontenc}% UTF-8 default; no inputenc
  \IfFileExists{microtype.sty}{\RequirePackage{microtype}}{}%
\else
  \IfFileExists{microtype.sty}{\RequirePackage{microtype}}{}%
\fi
% -----------------------------------------------------------------------

% Declare bachelor thesis switch.
\newif\if@ppbachelor\@ppbachelorfalse

%
% Declare default options and load base package (memoir).
%
\DeclareOption{bachelor}
   {\@ppbachelortrue}

\ExecuteOptions{a4paper,pl,11pt,oneside,final}
\DeclareOption*{\PassOptionsToClass{\CurrentOption}{memoir}}
\ProcessOptions\relax

%
% Require additional packages
%
\RequirePackage{babel}
\newif\if@pppolish
\iflanguage{polish}{\@pppolishtrue}{\@pppolishfalse}

\if@pppolish
\selectlanguage{polish}
\RequirePackage{indentfirst}
% Force "Literatura" instead of "Bibliografia"
\addto\captionspolish{\renewcommand{\bibname}{Literatura}}   
\else
\selectlanguage{english}
\fi

\RequirePackage{graphicx}
\RequirePackage{setspace}
\RequirePackage{booktabs}

\ifpdf
	\DeclareGraphicsExtensions{.pdf,.png,.jpg}
\else
	\DeclareGraphicsExtensions{.eps}
\fi
\RequirePackage{fancyvrb}

%
% Configure Hyperref
%

\RequirePackage{url}
\RequirePackage{nameref}
\RequirePackage{varioref}
  
\ifpdf
        \usepackage[unicode,linktocpage,bookmarks]{hyperref}
\else
        \usepackage[dvips,unicode,linktocpage,bookmarks]{hyperref}
\fi
\hypersetup{
    pdffitwindow=true,
    bookmarksnumbered=true,
    bookmarksopen=true,
    colorlinks=true,
    pdfpagelayout=SinglePage,
    pdfpagemode=UseOutlines,
    pdfstartview=Fit,
    linkcolor=black,
    citecolor=black,
    anchorcolor=black,
    filecolor=black,
    menucolor=black,
    urlcolor=black,
    pdftitle={},
    pdfauthor={},
    pdfkeywords={}
}
\RequirePackage{memhfixc}

%
% Emulate setspace package for older versions of memoir.
%
\ifx\undefined\SingleSpacing
\RequirePackage{setspace}
\newcommand{\SingleSpacing}{\singlespacing}
\fi
\ifx\undefined\OnehalfSpacing
\newcommand{\OnehalfSpacing}{\onehalfspacing}
\fi

%--------------------------------------
% Strona tytułowa pracy dyplomowej
%--------------------------------------

\aliaspagestyle{title}{empty}
\date{}




\newcommand{\ppsupervisor}[1]{\def\@ppsupervisor{#1}}
\newcommand{\ppyear}[1]{\def\@ppyear{#1}}
\newcommand{\ppinstitute}[1]{\def\@ppinstitute{#1}}

\newcommand{\authortitle}[1]{\def\@authortitle{#1}}

\setlength{\droptitle}{0cm}

\preauthor{\begin{center}\Large\@authortitle} 
\postauthor{\end{center}}

\renewcommand{\maketitlehooka}{%
\begin{center}
\if@pppolish
   \includegraphics[width=0.75\textwidth]{PUT/sygnet-pp.eps} \\
    WYDZIAŁ AUTOMATYKI, ROBOTYKI I ELEKTROTECHNIKI\\
\@ppinstitute
\else
    \includegraphics[width=0.75\textwidth]{PUT/sygnet-pp-eng.eps}  \\
FACULTY OF AUTOMATIC CONTROL, ROBOTICS, AND ELECTRICAL ENGINEERING\\
\@ppinstitute
\fi

\vspace{6mm}
\includegraphics[width=45mm]{PUT/logo-pp.pdf} \\

\end{center}}




\pretitle{\vspace{5mm}\begin{center}%
\if@pppolish%
  \if@ppbachelor 
     \Large{Projekt przejściowy}
   \else 
     \Large{Praca dyplomowa magisterska}
   \fi
\else
\if@ppbachelor 
\Large{Bachelor's thesis}
\else 
\Large{Master's thesis}
\fi
\fi\par\vspace{1cm}\Large\bfseries\MakeUppercase}
\posttitle{\end{center}}

\newcommand{\album}[1]{\unskip ,~#1}
\renewcommand{\and}{\\}

\renewcommand{\maketitlehookb}{\vspace{8mm}}

\renewcommand{\maketitlehookc}{\vfill\begin{center}
\if@pppolish
Prowadzący\\\@ppsupervisor
\else
Supervisor\\\@ppsupervisor
\fi\end{center}
  % <-- tu zostaje trochę miejsca na podpis / czytelność
  \vspace{8mm}

  % *** Ten blok zostaje zawsze na dole strony ***
  \begin{center}
    \vspace*{\fill}%
    POZNAŃ \@ppyear%
  \end{center}
}

%--------------------------------------
% Ostatnia strona z prawami autorskimi
%--------------------------------------

\newcommand{\ppcolophon}{%
\renewcommand{\and}{\unskip{}, }%
\renewcommand{\album}[1]{\unskip}%
\cleardoublepage\thispagestyle{empty}\vspace*{\fill}%
\footnotesize\SingleSpacing\noindent%
\raisebox{-1.3cm}{\includegraphics[height=1.5cm]{PUT/logo-pp}}%
\hspace{1.5em}%
\begin{minipage}[t]{11cm}%
\vglue 0pt\copyright{} \@ppyear\ \@author

\medskip\noindent%
\if@pppolish%
\@ppinstitute\\
Wydział Automatyki, Robotyki i Elektrotechniki \\ %
Politechnika Poznańska%
\else%
Poznan University of Technology\\
Faculty of Automatic Control, Robotics, and Electrical Engineering \\
\@ppinstitute\\
\fi

\medskip\noindent%
\if@pppolish%
Skład przy użyciu systemu \LaTeX{} na platformie Overleaf.%
\else%
Typeset using \LaTeX{} on Overleaf.%
\fi

\end{minipage}
}

%--------------------------------------
% Strony tytułowe rozdziałów
%--------------------------------------

\makepagestyle{ppfcmthesis}
\makeevenfoot{ppfcmthesis}{}{}{}
\makeatletter
\newcommand{\@ppfcmthesismarks}{%
  \let\@mkboth\markboth
  \def\chaptermark##1{\markboth{##1}{##1}}    % left mark & right marks
  \def\sectionmark##1{\markright{%
    \ifnum \c@secnumdepth>\z@
      \thesection. \ %
    \fi
    ##1}}
  \def\tocmark{\markboth{\contentsname}{}}
  \def\lofmark{\markboth{\listfigurename}{}}
  \def\lotmark{\markboth{\listtablename}{}}
  \def\bibmark{\markboth{\bibname}{}}
  \def\indexmark{\markboth{\indexname}{}}
}
\makepsmarks{ppfcmthesis}{\@ppfcmthesismarks}
\makeatother
\makeevenhead{ppfcmthesis}{\thepage}{}{\normalfont\small\itshape\leftmark}
\makeoddhead{ppfcmthesis}{\normalfont\small\itshape\rightmark}{}{\thepage}

%--------------------------------------
% Strona ze spisem treści
%--------------------------------------

\setcounter{tocdepth}{3}
\maxtocdepth{subsubsection}
\maxsecnumdepth{subsection}

%
% Customize book style
%
% \tightlists
\pagestyle{ppfcmthesis}
\setstocksize{297mm}{210mm}
\settrimmedsize{297mm}{210mm}{*}
\settrims{0pt}{0cm}
\setlrmarginsandblock{3.5cm}{2.5cm}{*}
\setulmarginsandblock{2.5cm}{2.5cm}{*}
\setmarginnotes{6pt}{50pt}{\onelineskip}
\setheadfoot{\onelineskip}{2\onelineskip}
\setheaderspaces{*}{2\onelineskip}{*}
\OnehalfSpacing

\changecaptionwidth
\captionwidth{.9\linewidth}
\captionnamefont{\footnotesize\scshape}
\captiontitlefont{\footnotesize}

\newcommand{\fcmfcaption}[2][\@empty]{
\captionnamefont{\footnotesize\bfseries}%
\captiondelim{.~}
\captionstyle{}
\captiontitlefont{\footnotesize}
\ifx #1\@empty \caption{#2}\else \caption[#1]{#2}}

\newcommand{\fcmtcaption}[2][\@empty]{
\captionnamefont{\footnotesize\bfseries\hfill}%
\captiondelim{}
\captionstyle{\raggedleft\\}
\captiontitlefont{\footnotesize\normalfont}
\ifx #1\@empty \caption{#2}\else \caption[#1]{#2}}

\def\thesubsubsection {\thesubsection .\arabic{subsubsection}}

\checkandfixthelayout

%
% Macros 
%

% English
\newcommand{\termdef}[1]{\emph{#1}}
\newcommand{\acronym}[1]{\emph{\MakeUppercase{#1}}}

% Polish
\newcommand{\definicja}[1]{\termdef{#1}}
\newcommand{\akronim}[1]{\acronym{#1}}
\newcommand{\english}[1]{ang.~\emph{#1}}

% Table head
\newcolumntype{L}{c}\newcommand{\tabhead}[1]{\multicolumn{1}{L}{#1}}